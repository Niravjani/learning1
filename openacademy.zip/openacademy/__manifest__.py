{
    "name": "Open Academy",
    "version": "1.0",
    "summary": "Open Academy Training Module",
    "author": "Nirav",
    "category": "Training",
    "license": "LGPL-3",
    "depends": [
        "base",
        "website",
    ],

    "data": [
        "security/ir.model.access.csv",
        "views/course_views.xml",
        "views/session_views.xml",
        "views/menu.xml",
        "views/website_template.xml",
    ],

    "installable": True,
    "application": True,
}
