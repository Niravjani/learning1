from odoo import models, fields


class OpenAcademyCourse(models.Model):
    _name = "openacademy.course"
    _description = "Open Academy Course"

    name = fields.Char(
        string="Course Title",
        required=True
    )

    md_subject = fields.Char(
        string="Subject"
    )

    md_description = fields.Text(
        string="Description"
    )

    md_dob = fields.Date(
        string="Date Of Birth"
    )

    md_contact = fields.Char(
        string="Contact Number"
    )

    md_email = fields.Char(
        string="Email"
    )

    md_address = fields.Text(
        string="Address"
    )

    md_notes = fields.Text(
        string="Notes"
    )

    md_responsibale_id = fields.Many2one("res.partner", string="Responsibale")

    md_session_ids = fields.One2many(
        "openacademy.session", "md_course_id", string="Sessions")
