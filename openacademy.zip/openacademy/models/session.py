from odoo import models, fields, api


class OpenAcademySession(models.Model):
    _name = "openacademy.session"
    _description = "Open Academy Session"

    name = fields.Char(
        string="Session Name",
        required=True
    )

    md_course_id = fields.Many2one(
        "openacademy.course",
        string="Course",
    )

    md_start_date = fields.Date(
        string="Start Date"
    )

    md_end_date = fields.Date(
        string="End Date"
    )

    md_duration = fields.Integer(
        string="Duration"
    )

    md_seats = fields.Integer(
        string="Seats"
    )

    md_attendees_ids = fields.Many2many(
        'res.partner',
        'session_attendees_id',
        's_id',
        'a_id'
    )

    md_taken_seats = fields.Float(
        string="Taken Seats",
        compute="_taken_seats",
        store=True
    )

    @api.depends("md_seats", "md_attendees_ids")
    def _taken_seats(self):
        for rec in self:
            if not rec.md_seats:
                rec.md_taken_seats = 0.0
            else:
                rec.md_taken_seats = (
                    100 * len(rec.md_attendees_ids) / rec.md_seats
                )
